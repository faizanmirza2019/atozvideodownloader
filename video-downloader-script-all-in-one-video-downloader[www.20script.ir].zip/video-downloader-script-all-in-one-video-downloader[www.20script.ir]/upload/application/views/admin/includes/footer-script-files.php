 </div>
	<script type="text/javascript" src="<?php echo base_url("assets/jquery/jquery.min.js"); ?>"></script>
	<script type="text/javascript" src="<?php echo base_url("assets/bootstrap/js/bootstrap.min.js"); ?>"></script>
	<script type="text/javascript" src="<?php echo base_url("assets/admin-js/sidebar-nav.min.js"); ?>"></script>
	<script type="text/javascript" src="<?php echo base_url("assets/admin-js/slimscroll.min.js"); ?>"></script>
	<script type="text/javascript" src="<?php echo base_url("assets/admin-js/waves.min.js"); ?>"></script>	
	<script type="text/javascript" src="<?php echo base_url("assets/admin-js/custom.min.js"); ?>"></script>
	<script type="text/javascript">
		var baseURL = '<?php echo base_url(); ?>';
		var adminURL = '<?php echo ADMIN_CONTROLLER ?>';
	</script>