<?php $pageName = $this->uri->segment(2); ?>
<div class="navbar-default sidebar" role="navigation">
	<div class="sidebar-nav slimscrollsidebar">
		<div class="sidebar-head">
			<h3><span class="fa-fw open-close"><i class="fa fa-times"></i></span> <span class="hide-menu">Navigation</span></h3>
		</div>
		<ul class="nav" id="side-menu">
			<li style="padding: 70px 0 0;">
				<a href="<?php echo base_url(ADMIN_CONTROLLER."/dashboard"); ?>" class="waves-effect">
					<i class="fa fa-tachometer fa-fw" aria-hidden="true"></i>Dashboard
				</a>
			</li>
			<li>
				<a href="<?php echo base_url(ADMIN_CONTROLLER."/general-settings"); ?>" class="waves-effect">
					<i class="fa fa-cog fa-fw" aria-hidden="true"></i>General Settings
				</a>
			</li>
			<li>
				<a href="<?php echo base_url(ADMIN_CONTROLLER."/sources"); ?>" class="waves-effect <?php echo($pageName == "edit-source" ? "active" : "not-active"); ?>">
					<i class="fa fa-area-chart fa-fw" aria-hidden="true"></i>Sources
				</a>
			</li>
			<!--<li>
				<a href="<?php //echo base_url(ADMIN_CONTROLLER."/api-keys"); ?>" class="waves-effect">
					<i class="fa fa-stack-overflow fa-fw" aria-hidden="true"></i>API Keys
				</a>
			</li>-->
			<li>
				<a href="<?php echo base_url(ADMIN_CONTROLLER."/captcha-settings"); ?>" class="waves-effect">
					<i class="fa fa-rocket fa-fw" aria-hidden="true"></i>Captcha Settings
				</a>
			</li>
			<li>
				<a href="<?php echo base_url(ADMIN_CONTROLLER."/analytics-settings"); ?>" class="waves-effect">
					<i class="fa fa-line-chart fa-fw" aria-hidden="true"></i>Analytics Settings
				</a>
			</li>
			<li>
				<a href="<?php echo base_url(ADMIN_CONTROLLER."/ads-settings"); ?>" class="waves-effect">
					<i class="fa fa-code fa-fw" aria-hidden="true"></i>Ads Settings
				</a>
			</li>
			<li>
				<a href="<?php echo base_url(ADMIN_CONTROLLER."/social-sharing"); ?>" class="waves-effect">
					<i class="fa fa-share fa-fw" aria-hidden="true"></i>Social Sharing
				</a>
			</li>
			<li>
				<a href="<?php echo base_url(ADMIN_CONTROLLER."/mail-settings"); ?>" class="waves-effect">
					<i class="fa fa-envelope fa-fw" aria-hidden="true"></i>Mail Settings
				</a>
			</li>
			<li>
				<a href="<?php echo base_url(ADMIN_CONTROLLER."/languages"); ?>" class="waves-effect <?php echo($pageName == "add-language" || $pageName == "edit-language" || $pageName == "edit-language-values" ? "active" : "not-active"); ?>">
					<i class="fa fa-language fa-fw" aria-hidden="true"></i>Languages
				</a>
			</li>
			<li>
				<a href="<?php echo base_url(ADMIN_CONTROLLER."/pages"); ?>" class="waves-effect <?php echo($pageName == "add-page" || $pageName == "edit-page" ? "active" : "not-active"); ?>">
					<i class="fa fa-file-o fa-fw" aria-hidden="true"></i>Pages
				</a>
			</li>
			<li>
				<a href="<?php echo base_url(ADMIN_CONTROLLER."/change-password"); ?>" class="waves-effect">
					<i class="fa fa-key fa-fw" aria-hidden="true"></i>Change Password
				</a>
			</li>
			<li>
				<a href="<?php echo base_url(ADMIN_CONTROLLER."/clear-cache"); ?>" class="waves-effect">
					<i class="fa fa-eraser fa-fw" aria-hidden="true"></i>Clear Cache
				</a>
			</li>
			<li>
				<a href="<?php echo base_url("logout"); ?>" class="waves-effect">
					<i class="fa fa-power-off fa-fw" aria-hidden="true"></i>Logout
				</a>
			</li>
		</ul>
	</div>
</div>