</head>
<body class="fix-header">
    <div class="preloader">
        <svg class="circular" viewBox="25 25 50 50">
            <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10" />
        </svg>
    </div>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-static-top m-b-0">
            <div class="navbar-header">
                <div class="top-left-part hidden-xs">
					<a class="logo" href="<?php echo base_url(ADMIN_CONTROLLER."/dashboard"); ?>">
						<span class="admin-logo">
							<img src="<?php echo base_url("assets/images/".$settings['logo']); ?>" alt="dashboard" class="img-responsive light-logo" />
						</span>
					</a>
                </div>
				<ul class="nav navbar-top-links navbar-left">
                    <li><a href="javascript:void(0)" class="open-close waves-effect waves-light wave-font"><i class="fa fa-bars"></i></a></li>
                </ul>
                <ul class="nav navbar-top-links navbar-right pull-right">
                    <li class="dropdown">
                        <a class="dropdown-toggle profile-pic" data-toggle="dropdown" href="#" aria-expanded="true">
							<?php
							$userInfo = $this->session->userdata('vds_user');
							$garavatar = "https://www.gravatar.com/avatar/".md5($userInfo['email']).".?s=40&d=".urlencode(base_url("assets/images/avatar.jpg"));
							?>
							<img src="<?php echo $garavatar; ?>" alt="user-img" width="36" class="img-circle"><b class="hidden-xs"><?php echo $userInfo['username']; ?></b>
							<span class="caret"></span>
						</a>
						<ul class="dropdown-menu dropdown-user animated flipInY">
							<li>
								<a href="<?php echo base_url(); ?>"><i class="fa fa-globe"></i> &nbsp;Visit Website</a>
							</li>
                            <li>
								<a href="<?php echo base_url(ADMIN_CONTROLLER."/change-password"); ?>"><i class="fa fa-key"></i> &nbsp;Change Password</a>
							</li>
                            <li>
								<a href="<?php echo base_url("logout"); ?>"><i class="fa fa-power-off"></i> &nbsp;Logout</a>
							</li>
                        </ul>
                    </li>
                </ul>
            </div>
        </nav>