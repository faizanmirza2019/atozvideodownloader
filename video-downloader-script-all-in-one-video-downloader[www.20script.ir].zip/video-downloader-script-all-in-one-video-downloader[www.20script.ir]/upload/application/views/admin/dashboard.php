<?php $this->load->view("admin/includes/head"); ?>
<title>Dashboard - <?php echo $settings['title']; ?></title>
<?php $this->load->view("admin/includes/header"); ?>
<?php $this->load->view("admin/includes/sidebar"); ?> 
<div id="page-wrapper" class="dashboard-page">
	<div class="container-fluid">
		<div class="row bg-title">
			<div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
				<h4 class="page-title"><i class="fa fa-tachometer"></i> Dashboard</h4>
			</div>
			<div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
				<ol class="breadcrumb">
					<li class="active"><a href="<?php echo base_url(ADMIN_CONTROLLER."/dashboard"); ?>">Dashboard</a></li>
				</ol>
			</div>
		</div>
		<?php
		foreach($stats as $row) {
			?>
			<h3><?php echo $row['type']; ?></h3>
			<div class="row">
				<div class="col-lg-4 col-sm-6 col-xs-12">
					<div class="white-box analytics-info">
						<ul class="list-inline two-part">
							<li class="text-left">
								<span class="text-success"><i class="fa fa-download"></i> &nbsp;Downloads</span>
							</li>
							<li class="text-right">
								<span class="counter text-success">
									<?php echo $row['stats']['downloads']; ?>
								</span>
							</li>
						</ul>
					</div>
				</div>
				<div class="col-lg-4 col-sm-6 col-xs-12">
					<div class="white-box analytics-info">
						<ul class="list-inline two-part">
							<li class="text-left">
								<span class="text-purple"><i class="fa fa-eye"></i> &nbsp;Page Views</span>
							</li>
							<li class="text-right">
								<span class="counter text-purple">
									<?php echo $row['stats']['pageViews']; ?>
								</span>
							</li>
						</ul>
					</div>
				</div>
				<div class="col-lg-4 col-sm-6 col-xs-12">
					<div class="white-box analytics-info">
						<ul class="list-inline two-part">
							<li class="text-left">
								<span class="text-info"><i class="fa fa-user"></i> &nbsp;Unique Views</span>
							</li>
							<li class="text-right">
								<span class="text-info">
									<?php echo $row['stats']['uniqueViews']; ?>
								</span>
							</li>
						</ul>
					</div>
				</div>
			</div>
			<?php
		}
		?>
	</div>
	<?php $this->load->view("admin/includes/footer-tag"); ?>
</div>
<?php $this->load->view("admin/includes/footer-script-files"); ?>
<?php $this->load->view("admin/includes/footer-end"); ?>