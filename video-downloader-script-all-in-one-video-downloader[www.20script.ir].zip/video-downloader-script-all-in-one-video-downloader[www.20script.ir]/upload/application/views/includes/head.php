<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="icon" href="<?php echo base_url("assets/images/".$settings['favicon']); ?>">
    <link type="text/css" href="<?php echo base_url("assets/bootstrap/css/bootstrap.min.css"); ?>" rel="stylesheet">
	<link type="text/css" href="<?php echo base_url("assets/font-awesome/css/font-awesome.min.css"); ?>" rel="stylesheet">
    <link type="text/css" href="<?php echo base_url("assets/css/style.css"); ?>" rel="stylesheet">
	