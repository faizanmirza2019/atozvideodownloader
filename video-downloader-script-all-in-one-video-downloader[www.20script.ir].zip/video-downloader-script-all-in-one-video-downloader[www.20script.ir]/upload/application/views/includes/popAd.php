<?php
$popAdFrequency = $adsSettings['popAdFrequency'];
$flag = 0;
if($popAdFrequency != 0) {
	$dataPA = $this->input->cookie("vds_PA",true);
	if($dataPA == NULL) {
		$dataPA = array();
		$frequency = 1;
		$dataPA['frequency'] = $frequency;
		$expire = 86400;
		$dataPA['expire'] = time() + $expire;
	}
	else {
		$dataPA = json_decode(base64_decode($dataPA),true);
		$frequency = $dataPA['frequency'] + 1;
		$dataPA['frequency'] = $frequency;
		$expire = $dataPA['expire'] - (time());
		$dataPA['expire'] = time() + $expire;
	}
	if($frequency <= $popAdFrequency) {
		$this->input->set_cookie("vds_PA",base64_encode(json_encode($dataPA)),$expire);
		$flag = 1;
	}
}
else {
	$flag = 1;
}

if($flag == 1) {
	echo stripcslashes(html_entity_decode($adsSettings['popAd'],ENT_QUOTES,"UTF-8"));
}
?>