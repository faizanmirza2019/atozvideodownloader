<div style="background-image:url(<?php echo base_url("assets/images/".$settings['backgroundImage']); ?>)" class="hero-section clearfix">
	<div class="container">
		<div class="download-holder">
			<h2>
				<a href="<?php echo base_url(); ?>">
					<img src="<?php echo base_url("assets/images/".$settings['logoLight']); ?>" class="center-block">
					<div class="clearfix"></div>
					<?php echo showLanguageVar($languageValues,"hero_section_title"); ?>
				</a>
			</h2>
			<div class="row">
				<div class="search col-md-8 col-md-offset-2">
					<form id="url-form" method="get" action="<?php echo base_url(); ?>">
						<div class="input-group">
							<input onclick="this.select();" id="url" type="text" class="form-control link-input" name="url" placeholder="<?php echo showLanguageVar($languageValues,"search_bar_placeholder"); ?>" value="<?php echo(isset($url) ? $url : ""); ?>" required />
							<span class="input-group-btn">
								<button class="btn btn-default link-btn" type="submit">
									<i class="glyphicon glyphicon-chevron-right"></i>
								</button>
							</span>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>