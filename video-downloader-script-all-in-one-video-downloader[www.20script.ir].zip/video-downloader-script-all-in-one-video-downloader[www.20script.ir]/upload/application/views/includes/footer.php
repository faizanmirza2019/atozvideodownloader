<footer>
    <div class="clearfix"></div>
    <div class="footer-wraper">
        <div class="container">
			<div class="row">
				<div class="col-md-6 footer-left-text">
					<a class="footer-small-logo" href="#">
						<img class="img-responsive" src="<?php echo base_url("assets/images/".$settings['logo']); ?>">
					</a>
					<span class="footer__copyright">
						<span class="opacity"><?php echo showLanguageVar($languageValues,"copyright")." ".date("Y"); ?> &copy;</span> <a href="<?php echo base_url(); ?>"><?php echo $settings['title']; ?></a>. <span class="opacity"><?php echo showLanguageVar($languageValues,"all_rights_reserved"); ?></span>
					</span>
				</div>
				<div class="col-md-6">
					<nav class="nav footer__nav">
						<?php 
							foreach($footerPages as $page) { 
								?>
								<a class="nav__item " href="<?php echo base_url("page/".$page['permalink']); ?>"><?php echo $page['title']; ?></a>
								<?php 
							} 
						?>
					</nav>
				</div>
			</div>
		</div>
    </div>
</footer>
<script type="text/javascript" src="<?php echo base_url("assets/jquery/jquery.min.js"); ?>"></script>
<script type="text/javascript" src="<?php echo base_url("assets/bootstrap/js/bootstrap.min.js"); ?>"></script>
<script type="text/javascript"> var baseUrl = '<?php echo base_url(); ?>'; </script>
<script type="text/javascript" src="<?php echo base_url("assets/js/custom.js"); ?>"></script>