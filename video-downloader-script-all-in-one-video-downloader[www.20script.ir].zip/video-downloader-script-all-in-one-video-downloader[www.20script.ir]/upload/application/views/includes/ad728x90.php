<div class="container p-t-15 p-b-15 text-center <?php echo($adsSettings['ad728x90ResponsiveStatus'] != 1 ? "hidden-xs" : ""); ?>">
	<?php echo stripcslashes(html_entity_decode($adsSettings['ad728x90'],ENT_QUOTES,"UTF-8")); ?>
</div>