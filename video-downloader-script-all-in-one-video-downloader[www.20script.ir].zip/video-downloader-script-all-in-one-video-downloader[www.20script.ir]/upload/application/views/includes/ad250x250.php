<div class="clearfix"></div>
<div class="p-t-15 text-center">
	<?php echo stripcslashes(html_entity_decode($adsSettings['ad250x250'],ENT_QUOTES,"UTF-8")); ?>
</div>