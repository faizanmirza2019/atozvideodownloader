<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="icon" href="<?php echo base_url("assets/images/".$settings['favicon']); ?>">
		<title><?php echo "404 Not Found - ".$settings['title']; ?></title>
		<meta name="description" content="<?php echo $settings['description']; ?>">
		<meta name="keywords" content="<?php echo $settings['keywords']; ?>">
		<link type="text/css" href="<?php echo base_url("assets/bootstrap/css/bootstrap.min.css"); ?>" rel="stylesheet">
		<link type="text/css" href="<?php echo base_url("assets/font-awesome/css/font-awesome.min.css"); ?>" rel="stylesheet">
		<link type="text/css" href="<?php echo base_url("assets/css/vert-offset.css"); ?>" rel="stylesheet">
		<link type="text/css" href="<?php echo base_url("assets/css/style.css"); ?>" rel="stylesheet">
		<?php if($analytics['status'] == 1) { echo stripcslashes(html_entity_decode($analytics['code'],ENT_QUOTES,"UTF-8")); } ?>
	</head>
	<body>
		<section id="wrapper" class="error-page">
			<div class="error-box">
				<div class="error-body text-center">
					<h1>404</h1>
					<h3 class="text-uppercase"><?php echo showLanguageVar($languageValues,"page_not_found"); ?></h3>
					<p class="text-muted m-t-30 m-b-30"><?php echo showLanguageVar($languageValues,"page_not_found_description"); ?></p>
					<a href="<?php echo base_url(); ?>" class="btn backToHome-btn m-b-40"><?php echo showLanguageVar($languageValues,"back_to_home"); ?></a>
				</div>
			</div>
		</section>
	</body>
</html>