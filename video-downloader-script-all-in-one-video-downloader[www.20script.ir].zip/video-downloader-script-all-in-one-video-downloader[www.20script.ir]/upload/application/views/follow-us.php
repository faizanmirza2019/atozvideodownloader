<div class="follow-us">
	<div class="container">
		<span class="follow-text"><?php echo showLanguageVar($languageValues,"stay_in_touch_with_us"); ?> </span>
		<?php
		if($socialSharing['facebookSharing'] == 1) {
			?>
			<span class="fb-btn">
				<div id="fb-root"></div>
				<script>(function(d, s, id) {
				var js, fjs = d.getElementsByTagName(s)[0];
				if (d.getElementById(id)) return;
				js = d.createElement(s); js.id = id;
				js.src = 'https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.11&appId=<?php echo $facebookAppId ?>';
				fjs.parentNode.insertBefore(js, fjs);
				}(document, 'script', 'facebook-jssdk'));</script>
				<div class="fb-like" data-href="https://web.facebook.com/<?php echo $socialSharing['facebookPageName']; ?>/" data-layout="button_count" data-action="like" data-size="small" data-show-faces="true" data-share="true"></div>
			</span>
			<?php
		}
		if($socialSharing['googleplusSharing'] == 1) {
			?>
			<span class="g-btn">
				<script src="https://apis.google.com/js/platform.js" async defer></script>
				<div class="g-follow" data-annotation="bubble" data-height="20" data-href="//plus.google.com/<?php echo $socialSharing['googleplusPageId']; ?>" data-rel="publisher"></div>
			</span>
			<?php
		}
		if($socialSharing['twitterSharing'] == 1) {
			?>
			<span class="t-btn">
				<script>
					window.twttr = (function(d, s, id) {
					var js, fjs = d.getElementsByTagName(s)[0],
					t = window.twttr || {};
					if (d.getElementById(id)) return t;
					js = d.createElement(s);
					js.id = id;
					js.src = "https://platform.twitter.com/widgets.js";
					fjs.parentNode.insertBefore(js, fjs);

					t._e = [];
					t.ready = function(f) {
					t._e.push(f);
					};

					return t;
					}(document, "script", "twitter-wjs"));
				</script>
				<a class="twitter-share-button" href="https://twitter.com/intent/tweet?text=<?php echo urlencode(str_replace("{{website title}}",$settings['title'],$socialSharing['twitterTweetText'])); ?>">Tweet</a>
			</span>
			<?php
		}
		if($socialSharing['linkedinSharing'] == 1) {
			?>
			<span class="l-btn">
				<script src="//platform.linkedin.com/in.js" type="text/javascript"> lang: en_US</script>
				<script type="IN/Share" data-url="<?php echo base_url(); ?>" data-counter="right"></script>
			</span>
			<?php
		}
		?>
	</div>
</div>