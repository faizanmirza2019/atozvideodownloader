<?php
function getLanguageRec() {
	$languageRec = array(
		"home" => [
			"title" => "Home",
			"value" => "Home"
		],
		"hero_section_title" => [
			"title" => "Hero Section Title",
			"value" => "Free Video Downloader online"
		],
		"search_bar_placeholder" => [
			"title" => "SearchBar Placeholder",
			"value" => "Enter your Video link here..."
		],
		"get_in_touch_with_us" => [
			"title" => "Get in touch with us",
			"value" => "Get in touch with us"
		],
		"source" => [
			"title" => "Source",
			"value" => "Source"
		],
		"share_on_facebook" => [
			"title" => "Share on Facebook",
			"value" => "Share on Facebook"
		],
		"share_on_twitter" => [
			"title" => "Share on Twitter",
			"value" => "Share on Twitter"
		],
		"share_on_googleplus" => [
			"title" => "Share on Google+",
			"value" => "Share on Google+"
		],
		"share_on_vk" => [
			"title" => "Share on VK",
			"value" => "Share on VK"
		],
		"share_on_whatsapp" => [
			"title" => "Share on WhatsApp",
			"value" => "Share on WhatsApp"
		],
		"video" => [
			"title" => "Video",
			"value" => "Video"
		],
		"video_only" => [
			"title" => "Video only",
			"value" => "Video only"
		],
		"more" => [
			"title" => "More",
			"value" => "More"
		],
		"less" => [
			"title" => "Less",
			"value" => "Less"
		],
		"audio" => [
			"title" => "Audio",
			"value" => "Audio"
		],
		"gif" => [
			"title" => "GIF",
			"value" => "GIF"
		],
		"quality" => [
			"title" => "Quality",
			"value" => "Quality"
		],
		"format" => [
			"title" => "Format",
			"value" => "Format"
		],
		"size" => [
			"title" => "Size",
			"value" => "Size"
		],
		"downloads" => [
			"title" => "Downloads",
			"value" => "Downloads"
		],
		"download" => [
			"title" => "Download",
			"value" => "Download"
		],
		"error" => [
			"title" => "Error",
			"value" => "Error"
		],
		"source_not_found_error" => [
			"title" => "Source not found error",
			"value" => "Currently this source isn't supported, maybe we will add it in future."
		],
		"video_not_found_error" => [
			"title" => "Video not found error",
			"value" => "Unable to fetch video, Invalid link or Video Doesn't Exist."
		],
		"invalid_url_error" => [
			"title" => "Invalid Url Error",
			"value" => "Invalid Url. Make sure url is with *{*http*}* or *{*https*}*"
		],
		"stay_in_touch_with_us" => [
			"title" => "Stay in touch with us",
			"value" => "Stay in touch with us"
		],
		"features_heading" => [
			"title" => "Features Heading",
			"value" => "Powerful Features to Download Videos"
		],
		"multiple_sources_heading" => [
			"title" => "Multiple Sources Section Heading",
			"value" => "Download Videos from Multiple Sources"
		],
		"multiple_sources_description" => [
			"title" => "Multiple Sources Section Description",
			"value" => "Video Downloader Script offers you to download videos from multiple sources which includes Youtube, Vimeo, Facebook, Dailymotion, SoundCloud, Instagram, Liveleak, Break and Imgur."
		],
		"multiple_formats_heading" => [
			"title" => "Multiple Formats Section Heading",
			"value" => "Download Videos in Multiple Formats"
		],
		"multiple_formats_description" => [
			"title" => "Multiple Formats Section Description",
			"value" => "Download videos in multiple formats including MP4, AVI, MP3, WEBM, 3GP."
		],
		"supported_sources" => [
			"title" => "Supported Sources",
			"value" => "Supported Sources"
		],
		"more_coming_soon" => [
			"title" => "More coming soon...",
			"value" => "More coming soon..."
		],
		"copyright" => [
			"title" => "Copyright",
			"value" => "Copyright"
		],
		"all_rights_reserved" => [
			"title" => "All Rights Reserved",
			"value" => "All Rights Reserved"
		],
		"contact_us" => [
			"title" => "Contact Us",
			"value" => "Contact Us"
		],
		"contact_page_heading" => [
			"title" => "Contact Page Heading",
			"value" => "Get in touch with us"
		],
		"enter_your_name" => [
			"title" => "Enter your Name",
			"value" => "Enter your Name..."
		],
		"enter_your_email" => [
			"title" => "Enter your email",
			"value" => "Enter your email..."
		],
		"enter_subject" => [
			"title" => "Enter subject",
			"value" => "Enter subject..."
		],
		"enter_your_message" => [
			"title" => "Enter your message",
			"value" => "Enter your message..."
		],
		"send" => [
			"title" => "Send",
			"value" => "Send"
		],
		"name_error" => [
			"title" => "Name Error",
			"value" => "Only A-z and spaces allowed"
		],
		"email_error" => [
			"title" => "Email Error",
			"value" => "Invalid email address"
		],
		"subject_error" => [
			"title" => "Subject Error",
			"value" => "Subject should not be empty"
		],
		"message_error" => [
			"title" => "Message Error",
			"value" => "Message should not be empty"
		],
		"captcha_error" => [
			"title" => "Captcha Error",
			"value" => "Invalid Captcha"
		],
		"page_not_found" => [
			"title" => "Page Not Found",
			"value" => "Page Not Found"
		],
		"page_not_found_description" => [
			"title" => "Page Not Found",
			"value" => "You seem to be trying to find this way home."
		],
		"back_to_home" => [
			"title" => "Back to home",
			"value" => "Back to home"
		],
		"here" => [
			"title" => "here",
			"value" => "here"
		],
		"dm_download_guide_heading" => [
			"title" => "Dailymotion download guide heading",
			"value" => "To Download video from dailymotion follow these steps"
		],
		"dm_download_guide_step_1" => [
			"title" => "Dailymotion download guide: step 1",
			"value" => "Goto the Video *{*page*}* by clicking"
		],
		"dm_download_guide_step_2" => [
			"title" => "Dailymotion download guide: step 2",
			"value" => "After opening the page press *{*ctrl + u*}* from keyboard or *{*Right Click*}* any where on page and click on *{*View Page Source*}*"
		],
		"dm_download_guide_step_3" => [
			"title" => "Dailymotion download guide: step 3",
			"value" => "Select all the source code by pressing *{*ctrl + a*}*"
		],
		"dm_download_guide_step_4" => [
			"title" => "Dailymotion download guide: step 4",
			"value" => "Copy all the source code by pressing *{*ctrl + c*}* or *{*Right Click*}* any where on page and click on *{*copy*}*"
		],
		"dm_download_guide_step_5" => [
			"title" => "Dailymotion download guide: step 5",
			"value" => "After copying came back to this page and paste the code in the *{*text box*}* below and click on *{*generate link*}* button"
		],
		"paste_source_code_here" => [
			"title" => "Paste source code here...",
			"value" => "Paste source code here..."
		],
		"generate_link" => [
			"title" => "Generate Link",
			"value" => "Generate Link"
		],
		"close" => [
			"title" => "Close",
			"value" => "Close"
		],
	);
	return $languageRec;
}
?>