<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-18 21:07:25 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\vds13\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-05-18 21:07:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\vds13\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-05-18 21:07:25 --> Unable to connect to the database
ERROR - 2018-05-18 21:07:25 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\vds13\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-05-18 21:07:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\vds13\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-05-18 21:07:25 --> Unable to connect to the database
ERROR - 2018-05-18 21:07:25 --> Query error: php_network_getaddresses: getaddrinfo failed: No such host is known.  - Invalid query: SELECT *
FROM `general-settings`
 LIMIT 1
ERROR - 2018-05-18 21:07:25 --> Severity: Error --> Call to a member function row_array() on boolean C:\xampp\htdocs\vds13\application\models\DefaultModel.php 23
