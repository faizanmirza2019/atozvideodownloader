<?php

/**
 * Description of Liveleak
 *
 * @author Nexthon
 */
/*
 {source_info}{"name":"Liveleak.com","website":"https:\/\/www.liveleak.com\/"}{end_source_info}
 */
class Liveleak 
{
  /*** Get liveleak video Info ***/
	public function getMediaInfo($url) {
		
		$data = array();
		$data['found'] = 0;
		$urlParts = parse_url($url);
		if(isset($urlParts['query'])) {
			parse_str($urlParts['query'], $query);
			if(isset($query['t'])) {
				$id = $query['t'];
				$resultM = getRemoteContents($url);
				if($resultM) {
					$result = getStringBetween($resultM,'<div class="embedWrapper"><iframe width=',' frameborder');
					if($result) {
								$link =  getStringBetween($result,'src="','?');
								
								$urlParts = parse_url($link);
								if(isset($urlParts['host']) && $urlParts['host'] = "www.youtube.com") {
									if(isset($urlParts['path'])) {
										$pathArr = explode("/",rtrim($urlParts['path'],"/"));
										$vid = $pathArr[2];
										if(count($pathArr) == 3 && $pathArr[1] == "embed") {
											$linkUrl = "https://www.youtube.com/watch?v=".$vid;
											$vare = &get_instance();
											$vare->load->library('youtube');

											$data = $vare->youtube->getMediaInfo($linkUrl);
										}
									}
								}
							
					} else {
					$videoHDlink = getStringBetween($resultM,'<source src="','" default');
                     $result = preg_replace('~>\\s+<~m', '><', $resultM);
					$videoSDlink = empty($videoHDlink) ? getStringBetween($result,'<source src="','"') : 
					getStringBetween($result,'type="video/mp4"><source src="','"  label');
	
					if($videoSDlink) {
						
						$data['found'] = 1;
						$data['id'] = $id;
						$links = array();
						
						$links['SD'] = $videoSDlink;
						if(!empty($videoHDlink)) {
							$links['HD'] = $videoHDlink;
						}
						$title = stripslashes(getStringBetween($result,"shareTitle: '","',
		shareUrl:"));
						$description = getStringBetween($result,'<meta property="og:description" content="','"/>');
						$image = getStringBetween($result,'<meta property="og:image" content="','"/>');
						$title = (!empty($title) ? htmlentities($title,ENT_QUOTES) : "Video By Liveleak");
						$data['title'] = $title;
						if(!empty($description)) {
							$data['description'] = htmlentities(truncate(trim(preg_replace('/[\s]+/',' ',preg_replace("/\r|\n/", " ", $description))),250),ENT_QUOTES);
						}
						else {
							$data['description'] = "Download ".$title." From Liveleak";
						}
						$data['image'] = $image;
						$thumbnailArr = explode("/",$image);
						$imageName = end($thumbnailArr);
						$imageNameArr = explode("_",$imageName);
						$embedId = $imageNameArr[0];
						$data['embedIframeDirect'] = "false";
						$embedIframe = str_replace("640","567",getStringBetween($result,"shareEmbed: '","',
				  endAction: '"));
						$data['embedIframe'] = $embedIframe;
						$data['script'] = '$("#embedModal").on("show.bs.modal",function() { $("#player-body").html(\''.$embedIframe.'\'); $("#player-id").on("load", function() { $("#loader-iframe").remove(); $(this).removeClass("hide"); }); }); $("#embedModal").on("hide.bs.modal",function() {$("#player-body").html("");});';
						$formatCodes = array (
							"SD" => array("order" => "1", "height" => "{{height}}", "ext" => "mp4", "resolution" => "SD", "video" => "true", "video_only" => "false"),
							"HD" => array("order" => "2", "height" => "{{height}}", "ext" => "mp4", "resolution" => "HD", "video" => "true", "video_only" => "false")
						);
						$videos = array();
						foreach($formatCodes as $formatId => $formatData) {
							if(isset($links[$formatId])) {
								$link = array();
								$link['data'] = $formatData;
								$link['formatId'] = $formatId;
								$link['order'] = $formatData['order'];
								$link['url'] = $links[$formatId];
								$link['title'] = $title.".".$formatData['ext'];
								$link['size'] = "unknown";
								array_push($videos,$link);	
							}
						}
						$data['videos'] = $videos;
					}
				}
			}
		  }
		}
		return $data;
	}
}