<?php

/**
 * Description of Imgur
 *
 * @author Nexthon
 */

/*
 {source_info}{"name":"Imgur.com","website":"https:\/\/www.imgur.com\/"}{end_source_info}
 */

class Imgur {
    //put your code here
    
    /*** Get Imgur gif Info ***/
	
	public function extract_albumdata($result,$id) {
	$data = array();
	$data['found'] = 1;
	$data['id'] = $id;
	$data['title'] = $result['data']['image']['title'];
	$data['description'] = "Download ".$data['title']." From Imgur";
	$data['image'] = "//i.imgur.com/" . $result['data']['image']['album_cover'] . ".jpg";
	$data['script'] = '$(document).on("click",".video-thumb",function() { window.open("https://imgur.com/gallery/' . $id . '", "_blank");});';
	$videos = array();
	$link = array();
	$link['data'] = "";
	$formatData['height'] = $result['data']['image']['album_cover_height'];
	$formatData['resolution'] = $result['data']['image']['album_cover_height']."p";
	$formatData['ext'] = 'mp4';
	$link['formatId'] = $result['data']['image']['album_cover_height'] . "p-mp4";
	$link['data'] = $formatData;
	$link['order'] = 1;
	$link['url'] = "https://i.imgur.com/". $result['data']['image']['album_cover'] . ".mp4";
	$link['title'] = rtrim($data['title'],".") . ".mp4";
	$link['size'] = "unknown";
	array_push($videos,$link);
	$link = array();
	$link['data'] = "";
	$formatData['height'] = $result['data']['image']['album_cover_height'];
	$formatData['resolution'] = $result['data']['image']['album_cover_height']."p";
	$formatData['ext'] = 'gif';
	$link['formatId'] = $result['data']['image']['album_cover_height'] . "p-gif";
	$link['data'] = $formatData;
	$link['order'] = 1;
	$link['url'] = "https://i.imgur.com/". $result['data']['image']['album_cover'] . ".gif";
	$link['title'] = rtrim($data['title'],".") . ".gif";
	$link['size'] = "unknown";
	array_push($videos,$link);
	$data['videos'] = $videos;
	return $data;
	}
	
	public function extractdata($result,$id) {
	$data = array();
	$data['found'] = 1;
	$data['id'] = $id;
	$data['title'] = $result['data']['image']['title'];
	$data['description'] = "Download ".$data['title']." From Imgur";
	$data['image'] = "//i.imgur.com/" . $id . ".jpg";
	$data['script'] = '$(document).on("click",".video-thumb",function() { window.open("https://imgur.com/gallery/' . $id . '", "_blank");});';
	$videos = array();
	$link = array();
	$link['data'] = "";
	$formatData['height'] = $result['data']['image']['height'];
	$formatData['resolution'] = $result['data']['image']['height']."p";
	$formatData['ext'] = 'mp4';
	$link['formatId'] = $result['data']['image']['height'] . "p-mp4";
	$link['data'] = $formatData;
	$link['order'] = 1;
	$link['url'] = "https://i.imgur.com/". $result['data']['image']['hash'] . ".mp4";
	$link['title'] = rtrim($data['title'],".") . ".mp4";
	$link['size'] = "unknown";
	array_push($videos,$link);
	$link = array();
	$link['data'] = "";
	$formatData['height'] = $result['data']['image']['height'];
	$formatData['resolution'] = $result['data']['image']['height']."p";
	$formatData['ext'] = 'gif';
	$link['formatId'] = $result['data']['image']['height'] . "p-gif";
	$link['data'] = $formatData;
	$link['order'] = 1;
	$link['url'] = "https://i.imgur.com/". $result['data']['image']['hash'] . ".gif";
	$link['title'] = rtrim($data['title'],".") . ".gif";
	$link['size'] = "unknown";
	array_push($videos,$link);
	$data['videos'] = $videos;
	return $data;
	}
	
	
	public function getMediaInfo($url) {
		$data = array();
		$data['found'] = 0;
		$id = pathinfo($url, PATHINFO_FILENAME);
		$result = json_decode(getRemoteContents($url. "/hit.json?all=true"),true);
		$formatCodes = array (
		"gif" => array("order" => "1", "height" => "{{height}}", "ext" => "gif", "resolution" => "{{resolution}}", "video" => "false", "video_only" => "false"),
		"mp4" => array("order" => "2", "height" => "{{height}}", "ext" => "mp4", "resolution" => "{{resolution}}", "video" => "true", "video_only" => "false"));
		if($result['data']['image']['id']) {
			if($result['data']['image']['is_album']) {
				return $this->extract_albumdata($result,$id);
			} else {
				return $this->extractdata($result,$id);
			}
		}
		return $data;
	}
}
