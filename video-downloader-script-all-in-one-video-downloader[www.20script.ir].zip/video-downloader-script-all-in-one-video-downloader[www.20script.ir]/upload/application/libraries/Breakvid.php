<?php


/**
 * Description of Break
 *
 * @author Nexthon
 */

/*
 {source_info}{"name":"Break.com","website":"https:\/\/www.break.com\/"}{end_source_info}
 */

class Breakvid 
{
   
        
    
        /*** Get Break video Info ***/
	 function getMediaInfo($url) 
        {
		$data = array();
		$data['found'] = 0;
		
		$context = [
                'http' => [
                    'method' => 'GET',
                    'header' => "User-Agent: " . $_SERVER['HTTP_USER_AGENT'],
                ],
            ];
			
        $context = stream_context_create($context);
			
        $resultM = file_get_contents($url, false, $context);
		
		//$resultM = getRemoteContents($url);
		//print_r($result);
		

		
					if($resultM) {
						
						$result = getStringBetween($resultM,'<iframe width=',' frameborder');
						if($result) {
								$link =  getStringBetween($result,'src="','?');
								
								$urlParts = parse_url($link);
								//print_r($urlParts);
								if(isset($urlParts['host']) && $urlParts['host'] = "www.youtube.com") {
									if(isset($urlParts['path'])) {
										$pathArr = explode("/",rtrim($urlParts['path'],"/"));
										//print_r($pathArr);
										$vid = $pathArr[2];
										if(count($pathArr) == 3 && $pathArr[1] == "embed") {
											$linkUrl = "https://www.youtube.com/watch?v=".$vid;
											//$this->load->helper("yt_func");
											$vare = &get_instance();
											$vare->load->library('youtube');

											$data = $vare->youtube->getMediaInfo($linkUrl);
										}
									}
								}
							
						}
						else {
							
							$result = getStringBetween($resultM,'var clipvars = ',';');
							
									$data['found'] = 1;
									$data['id'] = $id;
									$title = getStringBetween($resultM,'<title>','</title>');
									$data['title'] = $title;
									
									$data['description'] = "Download ".$title." From Break";
									
									$data['image'] = getStringBetween($resultM,'defaultThumbnailUrl": "','"');
									//$duration  = $result['videoLengthInSeconds'];
									//$data['time'] = gmdate(($duration > 3600 ? "H:i:s" : "i:s"), $duration);
									$videoSDlink =  getStringBetween($resultM,'[{"url":"','"');

       								 
           							 $links = array();

            						 $links['SD'] = $videoSDlink;
            
									
									
									
									$formatCodes = array(
               	 "SD" => array("order" => "1", "height" => "{{height}}", "ext" => "mp4", "resolution" => "SD", "video" => "true", "video_only" => "false"),
                "HD" => array("order" => "2", "height" => "{{height}}", "ext" => "mp4", "resolution" => "HD", "video" => "true", "video_only" => "false")
            );
            $videos = array();
            foreach ($formatCodes as $formatId => $formatData)
            {
                if (isset($links[$formatId]))
                {
                    $link = array();
                    $link['data'] = $formatData;
                    $link['formatId'] = $formatId;
                    $link['order'] = $formatData['order'];
                    $link['url'] = $links[$formatId];
                    $link['title'] = $title . "." . $formatData['ext'];
                    $link['size'] = "unknown";
                    array_push($videos, $link);
                }
            }
									
									$data['videos'] = $videos;
								
							
						}
					}
				
			
		
		return $data;
	}
}