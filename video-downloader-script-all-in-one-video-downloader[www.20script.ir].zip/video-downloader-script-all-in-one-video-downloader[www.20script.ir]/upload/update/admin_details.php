<?php 
session_start();
error_reporting(E_ALL);
if(!isset($_SESSION['update_step']) || $_SESSION['update_step'] < 3) {
	header("location:./database_details.php");
	exit();
}
include("db/connect.php");
if(isset($_POST['submit'])) {
	$error = false;
	$login = $_POST['login'];
	$password = $_POST['password'];
	$pass = md5($password);
	$rec = $mysqli->query("SELECT * FROM `users` WHERE (`username`='$login' OR `email`='$login') AND `password`='$pass' AND `role`='admin'");
	if($rec->num_rows > 0) {
		$_SESSION['update_step'] = 4;
		header("location:./database_quries.php");
		exit();
	}
	else {
		$error = true;
		$errorMsg = 'Invalid Admin Details.';
	}
}
include("includes/head.php"); 
?>
<title>Admin Details</title>
<?php include("includes/header.php"); ?>
<?php include("includes/sidebar.php"); ?>
<div class="rightSide">
	<div class="col-xs-12">
		<div class="tab-content shadow-1">
			<div class="tab-pane active">
				<form class="form-horizontal" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
					<?php
					if(isset($_POST['submit']) && $error == true) {
						?>
						<div class="alert alert-danger alert-dismissable">
							<a class="close" data-dismiss="alert" aria-label="close">&times;</a>
							<strong>Error!</strong> <?php echo $errorMsg; ?>
						</div>
						<?php
					}
					?>
					<div class="form-group">
						<label class="col-sm-3 control-label">Username Or Email</label>
						<div class="col-sm-9">
							<input type="text" name="login" placeholder="Username Or Email" class="form-control" required value="<?php echo (isset($login) ? $login : ""); ?>" />
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-3 control-label">Password</label>
						<div class="col-sm-9">
							<input type="password" name="password" placeholder="Password" class="form-control" required value="<?php echo (isset($password) ? $password : ""); ?>" />
						</div>
					</div>
					<div class="form-group">
						<div class="col-sm-offset-3 col-sm-8">
							<button type="submit" name="submit" class="btn btn-theme btn-lg">Submit</button>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<?php include("includes/footer.php"); ?>