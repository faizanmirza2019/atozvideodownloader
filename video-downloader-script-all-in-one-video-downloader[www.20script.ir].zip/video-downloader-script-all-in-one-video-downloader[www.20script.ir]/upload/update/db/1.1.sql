DROP TABLE IF EXISTS `api-keys`;
CREATE TABLE `api-keys` (
  `youtube` varchar(200) DEFAULT NULL,
  `facebookAppId` varchar(200) DEFAULT NULL,
  `facebookAppSecret` varchar(200) DEFAULT NULL,
  `soundcloud` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `api-keys` (`youtube`, `facebookAppId`, `facebookAppSecret`, `soundcloud`) VALUES (null,	null,	null,	'tqkXhayNt43gflO8R7OtxzEK80kdouPU');

ALTER TABLE `general-settings` DROP `facebookAppId`;

update `general-settings` SET `version`='1.1';