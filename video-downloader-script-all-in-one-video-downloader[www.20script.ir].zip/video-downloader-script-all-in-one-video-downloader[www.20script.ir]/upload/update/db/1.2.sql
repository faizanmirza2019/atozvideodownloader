ALTER TABLE `general-settings` ADD `allowDirectLink` int NULL AFTER `favicon`;

UPDATE `general-settings` SET `allowDirectLink` = '0';

DELETE FROM `sources` WHERE `id` = '1';

ALTER TABLE `api-keys` DROP `youtube`;

update `general-settings` SET `version`='1.2';