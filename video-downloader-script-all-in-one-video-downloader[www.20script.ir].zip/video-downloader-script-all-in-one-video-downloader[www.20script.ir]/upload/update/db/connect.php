<?php 
$server = "localhost";
$dbusername = "root";
$dbpassword = "hello";
$database = "vds";

$mysqli = new mysqli($server, $dbusername, $dbpassword, $database);
?>