DROP TABLE IF EXISTS `sources`;

DROP TABLE IF EXISTS `api-keys`;

update `general-settings` SET `version`='1.3';