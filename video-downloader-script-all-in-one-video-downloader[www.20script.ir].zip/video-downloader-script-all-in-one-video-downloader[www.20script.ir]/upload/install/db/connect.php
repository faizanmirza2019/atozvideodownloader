<?php 
$server = "localhost";
$dbusername = "root";
$dbpassword = "";
$database = "vds13final";

$mysqli = new mysqli($server, $dbusername, $dbpassword, $database);
?>