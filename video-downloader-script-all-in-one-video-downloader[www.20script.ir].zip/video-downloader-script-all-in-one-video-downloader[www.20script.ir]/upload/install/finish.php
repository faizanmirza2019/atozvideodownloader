<?php 
session_start();
error_reporting(E_ALL);
if(!isset($_SESSION['install_step']) || $_SESSION['install_step'] < 4) {
	header("location:./website_details_settings.php");
	exit();
}
include("db/connect.php");
$mysqli->query("UPDATE `general-settings` SET `installed`='1'");
unset($_SESSION['install_step']);

$dir = '../application/cache';
$leave_files = array('.htaccess', 'index.html');
foreach(glob("$dir/*") as $file) {
    if(!in_array(basename($file), $leave_files)) {
		unlink($file);
	}
}

$baseUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == "on"? 'https://' : 'http://').$_SERVER['SERVER_NAME'] . str_replace("/install","",dirname($_SERVER['SCRIPT_NAME']));

include("includes/head.php");
?>
<title>Finish Installation</title>
<?php include("includes/header.php"); ?>
<?php include("includes/sidebar.php"); ?>
<div class="rightSide">
	<div class="col-xs-12">
		<div class="tab-content shadow-1">
			<div role="tabpanel" class="tab-pane finish text-center active">
				
				<div class="form-group">
					<a href="<?php echo $baseUrl; ?>" class="btn btn-theme btn-lg">Visit Website</a>
				</div>
				<div class="alert alert-info">
					<i class="fa fa-exclamation-circle fa-lg"></i> Script has been installed successfully.
				</div>
				<p style="margin-top:10px">Note : Don't forget to delete the <strong>install</strong> and <strong>update</strong> directories.</p>
			</div>
		</div>
	</div>
</div>
<?php include("includes/footer.php"); ?>