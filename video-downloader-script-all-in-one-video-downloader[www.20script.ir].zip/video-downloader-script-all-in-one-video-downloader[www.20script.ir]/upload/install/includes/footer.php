</div>
</div>
<footer>
	© <?php echo date("Y"); ?> <a>Nexthon</a> - All Right Reserved [ www.20script.ir ]
</footer>
<script type="text/javascript" src="../assets/jquery/jquery.min.js"></script>
<script type="text/javascript" src="../assets/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>