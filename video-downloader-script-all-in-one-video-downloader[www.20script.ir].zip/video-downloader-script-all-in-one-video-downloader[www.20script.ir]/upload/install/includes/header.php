</head>
<body>
<div class="container themeTabs">
    <div class="row text-center">
        <div class="col-xs-12">
            <div class="logo">
                <img src="static/logo.png" width="200" class="img-responsive center-block">
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12 visible-xs">
            <div class="well">
                <i class="fa fa-bars fa-lg" data-toggle="collapse" data-target="#themeTabs" aria-expanded="false" aria-controls="themeTabs"></i>
            </div>
        </div>
		<div class="clearfix"></div>